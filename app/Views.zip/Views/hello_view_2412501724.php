<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hello</title>
</head>
<body>
    <h1>Salam Budi Luhur</h1>
    <?php foreach($mahasiswa as $item): ?>
        <h1>Nim : <?php echo $item['nim']; ?> </h1>
        <h1>Nama : <?php echo $item['nama']; ?> </h1>
    <?php endforeach; ?>
</body>
</html>