<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= isset($pelanggan) ? 'Edit Data : '.esc($pelanggan['nama']) : 'Tambah Pelanggan' ?></title>
  <link href="<?= base_url('css/bootstrap.min.css') ?>" rel="stylesheet">
  <style>
    .card-header-brand {
      background: linear-gradient(90deg,#06d6f2,#00cfe8);
      color: #fff;
    }
  </style>
</head>
<body>

<div class="container mt-4 mb-5">
  <a href="<?= base_url('pelanggan_2412500031') ?>" class="btn btn-secondary mb-3">Kembali</a>

  <div class="card">
    <div class="card-header card-header-brand">
      <h5 class="mb-0"><?= isset($pelanggan) ? 'Edit Data : '.esc($pelanggan['nama']) : 'Tambah Pelanggan' ?></h5>
    </div>

    <div class="card-body">
      <?php if(session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger">
          <?php foreach(session()->getFlashdata('errors') as $err): ?>
            <div><?= $err ?></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= isset($pelanggan) ? base_url('pelanggan_2412500031/update/'.$pelanggan['id']) : base_url('pelanggan_2412500031/store') ?>">
        <div class="mb-3">
          <label class="form-label">Nama</label>
          <input type="text" name="nama" class="form-control" value="<?= set_value('nama', isset($pelanggan) ? $pelanggan['nama'] : '') ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Alamat</label>
          <textarea name="alamat" class="form-control"><?= set_value('alamat', isset($pelanggan) ? $pelanggan['alamat'] : '') ?></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Telepon</label>
          <input type="text" name="telepon" class="form-control" value="<?= set_value('telepon', isset($pelanggan) ? $pelanggan['telepon'] : '') ?>">
        </div>

        <button type="submit" class="btn btn-success"><?= isset($pelanggan) ? 'Edit Data' : 'Simpan' ?></button>
      </form>
    </div>
  </div>
</div>

<script src="<?= base_url('js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
