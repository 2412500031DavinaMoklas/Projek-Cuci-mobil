<!DOCTYPE html>
<html>
<head>
    <title>Menu Utama</title>
</head>
<body>

<?php include "header.php"; ?>

<h1 style="text-align: center;">Selamat Datang di Halaman Utama</h1>
<p style="text-align: center;">Konten halaman Anda di sini...</p>

</body>
</html>
