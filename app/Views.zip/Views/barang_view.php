<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, initial-scale=1">
    <title>Data Barang</title>
    <link href="<?= base_url('css/bootstrap.min.css'); ?>" rel="stylesheet">
</head>
<body>

<?php include "header.php"; ?>

<div class="container mt-5">
    <a href="<?= base_url('barang/tambah'); ?>" class="btn btn-success mb-2">Tambah Data</a>
    <h2 class="mb-4 text-left">Daftar Barang</h2>
    <div class="card shadow rounded">
        <div class="card-body">
            <?php if (!empty($getBarang)) : ?>
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr align="center">
                        <th>KODE</th>
                        <th>Nama Barang</th>
                        <th>Qty</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                <?php $no = 1; foreach ($getBarang as $item) : ?>
                    <tr>
                        <!-- <td><?= $no++; ?></td> -->
                        <td><?= esc($item['id_barang']) ?></td>
                        <td><?= esc($item['nama_barang']) ?></td>
                        <td><?= esc($item['qty']) ?></td>
                        <td>Rp<?= number_format($item['harga_beli']); ?></td>
                        <td>Rp<?= number_format($item['harga_jual']); ?></td>
                        <td align="center">
                            <a href="<?= base_url('barang/edit/' . $item['id_barang']); ?>"
                               class="btn btn-success">
                               Edit</a>

                            <a href="<?= base_url('barang/hapus/' . $item['id_barang']); ?>"
                               onclick="javascript:return confirm('Apakah ingin menghapus data barang ?')"
                               class="btn btn-danger">
                               Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else : ?>
                <div class="alert alert-info text-center" role="alert">
                    Belum ada data barang.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Optional: Bootstrap JS -->
<script src="<?= base_url('js/bootstrap.bundle.min.js'); ?>"></script>
</body>
</html>