<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Daftar Pelanggan (2412500031)</title>
  <link href="<?= base_url('css/bootstrap.min.css') ?>" rel="stylesheet">
</head>
<body>

<div class="container mt-5 mb-5">
  <a href="<?= base_url('pelanggan_2412500031/create') ?>" class="btn btn-success mb-3">Tambah Data</a>
  <h2 class="mb-4">Daftar Pelanggan (2412500031)</h2>

  <?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <?php if(!empty($pelanggan)): ?>
  <div class="card shadow-sm">
    <div class="card-body p-0">
      <table class="table mb-0">
        <thead class="thead-dark">
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th style="width:140px">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($pelanggan as $p): ?>
          <tr>
            <td><?= esc($p['id']) ?></td>
            <td><?= esc($p['nama']) ?></td>
            <td><?= esc($p['alamat']) ?></td>
            <td><?= esc($p['telepon']) ?></td>
            <td>
              <a href="<?= base_url('pelanggan_2412500031/edit/'.$p['id']) ?>" class="btn btn-sm btn-success">Edit</a>
              <a href="<?= base_url('pelanggan_2412500031/delete/'.$p['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php else: ?>
    <div class="alert alert-info">Belum ada data pelanggan.</div>
  <?php endif; ?>
</div>

<!-- jangan panggil footer di sini untuk mencegah duplikat -->
<script src="<?= base_url('js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
