<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pelanggan</title>
    <link rel="stylesheet" href="<?= base_url('css/w3.css'); ?>">
</head>
<body>
    <div class="w3-container">
        <h2>Daftar Pelanggan</h2>
        <p>Isi halaman pelanggan di sini.</p>
    </div>
</body>
</html>