<!-- app/Views/footer.php -->
<!-- Footer sengaja dikosongkan supaya tidak tampilkan copyright -->
</body>
</html>
