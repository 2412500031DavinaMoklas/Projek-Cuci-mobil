<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, initial-scale=1">
    <title>Data Barang</title>

    <!-- Bootstrap 5 CDN -->
    <link href="<?= base_url('css/bootstrap.min.css'); ?>" rel="stylesheet">
</head>

<body>
<?php include "header.php"; ?>

<div class="container p-5">
    <a href="<?= base_url('barang'); ?>" class="btn btn-secondary mb-2">Kembali</a>

    <div class="card">
        <div class="card-header bg-info text-white">
            <h4 class="card-title">Tambah Data Barang</h4>
        </div>

        <div class="card-body">
            <form method="post" action="<?= base_url('barang/add'); ?>">
                
                <div class="form-group">
                    <label for="">ID Barang</label>
                    <input type="text" name="id" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="">Nama Barang</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="">Qty</label>
                    <input type="number" name="qty" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="">Harga Beli</label>
                    <input type="number" name="beli" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="">Harga Jual</label>
                    <input type="number" name="jual" class="form-control" required>
                </div>

                <button class="btn btn-success mt-3">Tambah Data</button>
            </form>
        </div>
    </div>
</div>

<!-- Optional: Bootstrap JS -->
<script src="<?= base_url('js/bootstrap.bundle.min.js'); ?>"></script>

</body>
</html>
