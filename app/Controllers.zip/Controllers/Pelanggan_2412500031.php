<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PelangganModel_2412500031;

class Pelanggan_2412500031 extends BaseController
{
    protected $pelModel;
    protected $helpers = ['form', 'url'];

    public function __construct()
    {
        $this->pelModel = new PelangganModel_2412500031();
    }

    public function index()
    {
        $data['pelanggan'] = $this->pelModel->orderBy('id','ASC')->findAll();
        echo view('header'); // jika Anda pakai header.php
        echo view('pelanggan_list_2412500031', $data);
        echo view('footer'); // opsional jika ada footer.php
    }

    public function create()
    {
        $data = [];
        echo view('header');
        echo view('pelanggan_form_2412500031', $data);
        echo view('footer');
    }

    public function store()
    {
        $validation = \Config\Services::validation();
        $rules = ['nama' => 'required|min_length[2]|max_length[100]'];

        if (! $this->validate($rules)) {
            // kirim kembali error ke form
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('pelanggan_2412500031/create'))->withInput();
        }

        $this->pelModel->insert([
            'nama'    => $this->request->getPost('nama'),
            'alamat'  => $this->request->getPost('alamat'),
            'telepon' => $this->request->getPost('telepon'),
        ]);

        session()->setFlashdata('success', 'Data pelanggan berhasil disimpan.');
        return redirect()->to(base_url('pelanggan_2412500031'));
    }

    public function edit($id = null)
    {
        $pel = $this->pelModel->find($id);
        if (!$pel) {
            session()->setFlashdata('error', 'Data tidak ditemukan.');
            return redirect()->to(base_url('pelanggan_2412500031'));
        }
        $data['pelanggan'] = $pel;
        echo view('header');
        echo view('pelanggan_form_2412500031', $data);
        echo view('footer');
    }

    public function update($id = null)
    {
        if ($id === null) return redirect()->to(base_url('pelanggan_2412500031'));

        $validation = \Config\Services::validation();
        $rules = ['nama' => 'required|min_length[2]|max_length[100]'];

        if (! $this->validate($rules)) {
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url("pelanggan_2412500031/edit/{$id}"))->withInput();
        }

        $this->pelModel->update($id, [
            'nama' => $this->request->getPost('nama'),
            'alamat' => $this->request->getPost('alamat'),
            'telepon' => $this->request->getPost('telepon'),
        ]);

        session()->setFlashdata('success', 'Data pelanggan berhasil diupdate.');
        return redirect()->to(base_url('pelanggan_2412500031'));
    }

    public function delete($id = null)
    {
        if ($id !== null) {
            $this->pelModel->delete($id);
            session()->setFlashdata('success', 'Data pelanggan berhasil dihapus.');
        }
        return redirect()->to(base_url('pelanggan_2412500031'));
    }
}
