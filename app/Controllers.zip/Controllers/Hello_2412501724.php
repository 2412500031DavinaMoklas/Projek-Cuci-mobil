<?php

namespace App\Controllers;
use App\Models\mahasiswa_2412501724;

class Hello_2412501724 extends BaseController
{
    public function index(): string
    {
        $mhsModel = new mahasiswa_2412501724();
        $data['mahasiswa'] = $mhsModel->get_mahasiswa();
        return view('hello_view_2412501724', $data);
    }
}
